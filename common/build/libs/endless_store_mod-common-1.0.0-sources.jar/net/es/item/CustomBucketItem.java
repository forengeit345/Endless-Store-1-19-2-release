package net.es.item;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1755;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2263;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_2402;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3486;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5328;
import net.minecraft.class_5712;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.Nullable;

public class CustomBucketItem extends class_1755 {
    private final class_3611 content;

    public CustomBucketItem(class_3611 fluid, class_1793 properties) {
        super(fluid, properties);
        this.content = fluid;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 itemStack = player.method_5998(hand);
        class_3965 blockHitResult = method_7872(level, player, this.content == class_3612.field_15906 ? class_3959.class_242.field_1345 : class_3959.class_242.field_1348);
        if (blockHitResult.method_17783() == class_239.class_240.field_1333) {
            return class_1271.method_22430(itemStack);
        } else if (blockHitResult.method_17783() != class_239.class_240.field_1332) {
            return class_1271.method_22430(itemStack);
        } else {
            class_2338 blockPos = blockHitResult.method_17777();
            class_2350 direction = blockHitResult.method_17780();
            class_2338 blockPos2 = blockPos.method_10093(direction);
            if (level.method_8505(player, blockPos) && player.method_7343(blockPos2, direction, itemStack)) {
                if (this.content == class_3612.field_15906) {
                    class_2680 blockState = level.method_8320(blockPos);
                    if (blockState.method_26204() instanceof class_2263 bucketPickup) {
                        class_1799 filledStack = bucketPickup.method_9700(player, level, blockPos, blockState);
                        if (!filledStack.method_7960()) {
                            player.method_7259(class_3468.field_15372.method_14956(this));
                            bucketPickup.method_32351().ifPresent(sound -> player.method_5783(sound, 1.0F, 1.0F));
                            level.method_33596(player, class_5712.field_28167, blockPos);
                            class_1799 result = class_5328.method_30012(itemStack, player, filledStack);
                            if (!level.field_9236) {
                                class_174.field_1208.method_8932((class_3222) player, filledStack);
                            }
                            return class_1271.method_29237(result, level.method_8608());
                        }
                    }
                    return class_1271.method_22431(itemStack);
                } else {
                    class_2680 blockState = level.method_8320(blockPos);
                    class_2338 placePos = blockState.method_26204() instanceof class_2402 && this.content == class_3612.field_15910 ? blockPos : blockPos2;
                    if (this.method_7731(player, level, placePos, blockHitResult)) {
                        this.method_7728(player, level, itemStack, placePos);
                        if (player instanceof class_3222) {
                            class_174.field_1191.method_23889((class_3222) player, placePos, itemStack);
                        }
                        player.method_7259(class_3468.field_15372.method_14956(this));
                        class_1799 result = class_5328.method_30012(itemStack, player, method_7732(itemStack, player));
                        return class_1271.method_29237(result, level.method_8608());
                    } else {
                        return class_1271.method_22431(itemStack);
                    }
                }
            } else {
                return class_1271.method_22431(itemStack);
            }
        }
    }

    public static class_1799 method_7732(class_1799 stack, class_1657 player) {
        class_1792 emptyBucket = EndlessStoreItems.PLASTIC_BUCKET_ITEM.get();
        return !player.method_56992() ? new class_1799(emptyBucket) : stack;
    }

    public boolean method_7731(@Nullable class_1657 player, class_1937 level, class_2338 pos, @Nullable class_3965 hitResult) {
        class_3611 fluid = this.content;
        if (!(fluid instanceof class_3609 flowingFluid)) {
            return false;
        }
        class_2680 blockState = level.method_8320(pos);
        boolean canPlace = blockState.method_26188(fluid);
        if (!blockState.method_26215() && !canPlace) {
            if (blockState.method_26204() instanceof class_2402 liquidBlockContainer) {
                if (!liquidBlockContainer.method_10310(player, level, pos, blockState, fluid)) {
                    return false;
                }
            } else {
                return false;
            }
        }
        if (level.method_8597().comp_644() && fluid.method_15791(class_3486.field_15517)) {
            int i = pos.method_10263();
            int j = pos.method_10264();
            int k = pos.method_10260();
            level.method_8396(player, pos, class_3417.field_15102, class_3419.field_15245, 0.5F, 2.6F + (level.field_9229.method_43057() - level.field_9229.method_43057()) * 0.8F);
            for (int l = 0; l < 8; ++l) {
                level.method_8406(class_2398.field_11237, (double) i + Math.random(), (double) j + Math.random(), (double) k + Math.random(), 0.0, 0.0, 0.0);
            }
            return true;
        }
        if (blockState.method_26204() instanceof class_2402 && fluid == class_3612.field_15910) {
            ((class_2402) blockState.method_26204()).method_10311(level, pos, blockState, flowingFluid.method_15729(false));
            this.playEmptySound(player, level, pos);
            return true;
        }
        if (!level.field_9236 && canPlace && !blockState.method_51176()) {
            level.method_22352(pos, true);
        }
        if (!level.method_8652(pos, fluid.method_15785().method_15759(), 11) && !blockState.method_26227().method_15771()) {
            return false;
        }
        this.playEmptySound(player, level, pos);
        return true;
    }

    protected void playEmptySound(@Nullable class_1657 player, class_1937 level, class_2338 pos) {
        class_3414 sound = this.content.method_15791(class_3486.field_15518) ? class_3417.field_15010 : class_3417.field_14834;
        level.method_8396(player, pos, sound, class_3419.field_15245, 1.0F, 1.0F);
        level.method_33596(player, class_5712.field_28166, pos);
    }
}