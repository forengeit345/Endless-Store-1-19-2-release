package net.es.item;

import com.google.common.base.Suppliers;
import net.es.EndlessStoreMod;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.function.Supplier;

public class EndlessStoreItemGroup {
    public static final Supplier<class_1761> ENDLESS_STORE_TAB = Suppliers.memoize(() ->
            class_1761.method_47307(class_1761.class_7915.field_41049, 0)
                    .method_47320(() -> new class_1799(class_7923.field_41178.method_10223(
                            class_2960.method_60655(EndlessStoreMod.MOD_ID, "wooden_board")
                    )))
                    .method_47321(class_2561.method_43471("itemGroup." + EndlessStoreMod.MOD_ID + ".endless_store_tab"))
                    .method_47324()
    );
}