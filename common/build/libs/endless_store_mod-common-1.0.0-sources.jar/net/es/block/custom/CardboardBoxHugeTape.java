package net.es.block.custom;

import com.mojang.serialization.MapCodec;
import net.es.block.entity.CardboardBoxHugeTapeEntity;
import net.minecraft.class_10;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3218;
import net.minecraft.class_3468;
import net.minecraft.class_3726;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;

public class CardboardBoxHugeTape extends class_2237 {
    public static final MapCodec<CardboardBoxHugeTape> CODEC = method_54094(CardboardBoxHugeTape::new);

    public static Supplier<class_2591<CardboardBoxHugeTapeEntity>> TYPE = () -> {
        throw new IllegalStateException("CardboardBoxHugeTape type not initialized");
    };

    public static final class_2753 FACING = class_2741.field_12481;

    public CardboardBoxHugeTape(class_2251 properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    private static final class_265 SHAPE = class_2248.method_9541(0, 0, 0, 16, 16, 16);

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
        if (level.field_9236) {
            return class_1269.field_5812;
        } else {
            class_3908 menuProvider = this.method_17454(state, level, pos);
            if (menuProvider != null) {
                player.method_17355(menuProvider);
                player.method_7281(class_3468.field_15395);
            }
            return class_1269.field_21466;
        }
    }

    @Override
    public void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            class_2586 blockEntity = level.method_8321(pos);
            if (blockEntity instanceof net.minecraft.class_1263 container) {
                class_1264.method_5451(level, pos, container);
            }
            super.method_9536(state, level, pos, newState, moved);
        }
    }

    @Override
    public void method_9588(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof CardboardBoxHugeTapeEntity) {
            ((CardboardBoxHugeTapeEntity) blockEntity).tick();
        }
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new CardboardBoxHugeTapeEntity(pos, state);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    protected boolean method_9516(class_2680 state, class_10 pathComputationType) {
        return false;
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }
}