package net.es.block.custom;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_10;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

public class WoodenChair extends class_2383 {
    public static final MapCodec<WoodenChair> CODEC = method_54094(WoodenChair::new);

    public WoodenChair(class_2251 properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }

    private static final class_265 SHAPE_N = class_259.method_1084(
            class_2248.method_9541(2, 0, 2, 14.5, 7.7, 14.5),
            class_2248.method_9541(2, 0, 2, 14.5, 20, 3.5)
    );
    private static final class_265 SHAPE_S = class_259.method_1084(
            class_2248.method_9541(1.5, 0, 1.5, 14, 7.7, 14),
            class_2248.method_9541(1.5, 0, 12.5, 14, 20, 14)
    );
    private static final class_265 SHAPE_E = class_259.method_1084(
            class_2248.method_9541(1.5, 0, 2, 14, 7.7, 14.5),
            class_2248.method_9541(12.5, 0, 2, 14, 20, 14.5)
    );
    private static final class_265 SHAPE_W = class_259.method_1084(
            class_2248.method_9541(2, 0, 2, 14.5, 7.7, 14.5),
            class_2248.method_9541(2, 0, 2, 3.5, 20, 14.5)
    );

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return switch (state.method_11654(field_11177)) {
            case field_11043 -> SHAPE_S;
            case field_11035 -> SHAPE_N;
            case field_11039 -> SHAPE_E;
            case field_11034 -> SHAPE_W;
            default -> SHAPE_N;
        };
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 context) {
        return this.method_9564().method_11657(field_11177, context.method_8042().method_10153());
    }
    @Override
    protected boolean method_9516(class_2680 state, class_10 pathComputationType) {
        return false;
    }

    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(field_11177, rotation.method_10503(state.method_11654(field_11177)));
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(field_11177)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177);
    }
}