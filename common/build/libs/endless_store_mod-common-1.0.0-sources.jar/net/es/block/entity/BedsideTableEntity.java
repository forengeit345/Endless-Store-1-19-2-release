package net.es.block.entity;

import net.es.block.custom.BedsideTable;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2621;
import net.minecraft.class_2680;
import net.minecraft.class_5561;
import net.minecraft.class_7225;

public class BedsideTableEntity extends class_2621 {
    private class_2371<class_1799> inventory;
    private final class_5561 openersCounter;

    private static class_2591<BedsideTableEntity> type() {
        return BedsideTable.TYPE.get();
    }

    public BedsideTableEntity(class_2338 pos, class_2680 state) {
        super(type(), pos, state);
        this.inventory = class_2371.method_10213(27, class_1799.field_8037);
        this.openersCounter = new class_5561() {
            @Override
            protected void method_31681(class_1937 level, class_2338 pos, class_2680 state) {
                // Можно добавить звук открытия при необходимости
            }

            @Override
            protected void method_31683(class_1937 level, class_2338 pos, class_2680 state) {
                // Можно добавить звук закрытия при необходимости
            }

            @Override
            protected void method_31682(class_1937 level, class_2338 pos, class_2680 state, int oldCount, int newCount) {
            }

            @Override
            protected boolean method_31679(class_1657 player) {
                if (player.field_7512 instanceof class_1707 menu) {
                    class_1263 container = menu.method_7629();
                    return container == BedsideTableEntity.this;
                }
                return false;
            }
        };
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11014(tag, registries);
        this.inventory = class_2371.method_10213(this.method_5439(), class_1799.field_8037);
        if (!this.method_54871(tag)) {
            class_1262.method_5429(tag, this.inventory, registries);
        }
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11007(tag, registries);
        if (!this.method_54872(tag)) {
            class_1262.method_5426(tag, this.inventory, registries);
        }
    }
    @Override
    public int method_5439() {
        return 27;
    }

    @Override
    protected class_2371<class_1799> method_11282() {
        return this.inventory;
    }

    @Override
    protected void method_11281(class_2371<class_1799> list) {
        this.inventory = list;
    }

    @Override
    protected class_2561 method_17823() {
        return class_2561.method_43471("container.bedside_table");
    }

    @Override
    protected class_1703 method_5465(int syncId, class_1661 playerInventory) {
        return class_1707.method_19245(syncId, playerInventory, this);
    }

    @Override
    public void method_5435(class_1657 player) {
        if (!this.field_11865 && !player.method_7325()) {
            this.openersCounter.method_31684(player, this.method_10997(), this.method_11016(), this.method_11010());
        }
    }

    @Override
    public void method_5432(class_1657 player) {
        if (!this.field_11865 && !player.method_7325()) {
            this.openersCounter.method_31685(player, this.method_10997(), this.method_11016(), this.method_11010());
        }
    }

    public void tick() {
        if (!this.field_11865) {
            this.openersCounter.method_31686(this.method_10997(), this.method_11016(), this.method_11010());
        }
    }
}