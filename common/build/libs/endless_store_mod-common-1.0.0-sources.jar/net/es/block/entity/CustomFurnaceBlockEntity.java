package net.es.block.entity;

import net.es.block.custom.CustomFurnaceBlock;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2609;
import net.minecraft.class_2680;
import net.minecraft.class_3858;
import net.minecraft.class_3956;

public class CustomFurnaceBlockEntity extends class_2609 {
    public CustomFurnaceBlockEntity(class_2338 pos, class_2680 state) {
        super(CustomFurnaceBlock.TYPE.get(), pos, state, class_3956.field_17546);
    }

    @Override
    protected class_2561 method_17823() {
        return class_2561.method_43471("container.furnace");
    }

    @Override
    protected class_1703 method_5465(int syncId, class_1661 inventory) {
        return new class_3858(syncId, inventory, this, this.field_17374);
    }
}