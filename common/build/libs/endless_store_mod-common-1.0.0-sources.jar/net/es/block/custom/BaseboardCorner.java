package net.es.block.custom;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_10;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

import javax.swing.text.html.BlockView;

import static javax.swing.SwingConstants.NORTH;
import static net.es.block.custom.Baseboard.FACING;

public class BaseboardCorner extends class_2346 {
    public static final MapCodec<BaseboardCorner> CODEC = method_54094(BaseboardCorner::new);

    public BaseboardCorner(class_2251 properties) {
        super(properties);
    }

    private static final class_265 SHAPE_N = class_259.method_1084(
            class_2248.method_9541(0, 0, 0, 0.75, 1.5, 16),
            class_2248.method_9541(0.75, 0, 0, 16, 1.5, 0.75)
    );
    private static final class_265 SHAPE_E = class_259.method_1084(
            class_2248.method_9541(0, 0, 0, 16, 1.5, 0.75),
            class_2248.method_9541(15.25, 0, 0.75, 16, 1.5, 16)
    );
    private static final class_265 SHAPE_S = class_259.method_1084(
            class_2248.method_9541(15.25, 0, 0, 16, 1.5, 16),
            class_2248.method_9541(0, 0, 15.25, 15.25, 1.5, 16)
    );
    private static final class_265 SHAPE_W = class_259.method_1084(
            class_2248.method_9541(0, 0, 15.25, 16, 1.5, 16),
            class_2248.method_9541(0, 0, 0, 0.75, 1.5, 15.25)
    );

    @Override
    protected MapCodec<? extends class_2346> method_53969() {
        return field_46280;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return switch (state.method_11654(FACING)) {
            case field_11043 -> SHAPE_N;
            case field_11035 -> SHAPE_W;
            case field_11039 -> SHAPE_S;
            case field_11034 -> SHAPE_E;
            default -> SHAPE_N;
        };
    }


    @Override
    public class_265 method_9549(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return class_259.method_1073();
    }

    @Override
    protected boolean method_9516(class_2680 state, class_10 pathComputationType) {
        return true;
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        class_2338 below = pos.method_10074();
        return class_2248.method_20044(level, below, class_2350.field_11036);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 context) {
        return this.method_9564().method_11657(FACING, context.method_8042().method_10153());
    }


    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }
}