package net.es.entity;

import net.es.block.custom.Plate;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3417;

public class PlateEntity extends class_1297 {
    private static final class_2940<class_1799> DATA_ITEM =
            class_2945.method_12791(PlateEntity.class, class_2943.field_13322);
    private static final class_2940<Integer> DATA_ROTATION =
            class_2945.method_12791(PlateEntity.class, class_2943.field_13327);

    private class_2338 platePos; // позиция блока тарелки

    public PlateEntity(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
        this.field_5960 = true;   // полностью отключаем физику/коллизию
        this.method_5814(0, 0, 0);   // начальная заглушка, переопределится при recreate
    }

    public PlateEntity(class_1937 level, class_2338 pos, class_2350 facing) {
        this(EndlessStoreEntities.PLATE.get(), level);
        this.platePos = pos.method_10062();
        // Явно фиксируем точное положение над центром тарелки
        this.method_5814(pos.method_10263() + 0.5, pos.method_10264() + 0.03125, pos.method_10260() + 0.5);
        // Базовый поворот по направлению блока (как у рамки)
        int rotation = 0;
        if (facing.method_10166().method_10179()) {
            rotation = switch (facing) {
                case field_11034 -> 2;
                case field_11035 -> 4;
                case field_11039 -> 6;
                default -> 0; // NORTH
            };
        }
        this.field_6011.method_12778(DATA_ROTATION, rotation);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(DATA_ITEM, class_1799.field_8037);
        builder.method_56912(DATA_ROTATION, 0);
    }

    // --- Геттеры / сеттеры ---
    public class_1799 getItem() {
        return this.field_6011.method_12789(DATA_ITEM);
    }

    public void setItem(class_1799 stack) {
        if (!stack.method_7960()) {
            stack = stack.method_46651(1);
        }
        this.field_6011.method_12778(DATA_ITEM, stack);
    }

    public int getRotation() {
        return this.field_6011.method_12789(DATA_ROTATION);
    }

    public void setRotation(int rotation) {
        this.field_6011.method_12778(DATA_ROTATION, rotation % 8);
    }

    // --- Взаимодействие (вызывается из блока) ---
    @Override
    public class_1269 method_5688(class_1657 player, class_1268 hand) {
        class_1799 playerStack = player.method_5998(hand);
        if (this.method_37908().field_9236) {
            return class_1269.field_5812;
        }
        if (!this.getItem().method_7960() && playerStack.method_7960()) {
            player.method_6122(hand, this.getItem().method_7972());
            this.setItem(class_1799.field_8037);
            this.method_5783(class_3417.field_14770, 1.0F, 1.0F);
            return class_1269.field_21466;
        } else if (!playerStack.method_7960() && this.getItem().method_7960()) {
            class_1799 toPlace = playerStack.method_7972();
            toPlace.method_7939(1);
            this.setItem(toPlace);
            if (!player.method_7337()) {
                playerStack.method_7934(1);
            }
            this.method_5783(class_3417.field_14667, 1.0F, 1.0F);
            return class_1269.field_21466;
        } else if (playerStack.method_7960() && !this.getItem().method_7960() && hand == class_1268.field_5808) {
            setRotation((getRotation() + 1) % 8);
            this.method_5783(class_3417.field_15038, 1.0F, 1.0F);
            return class_1269.field_21466;
        }
        return class_1269.field_5811;
    }

    // --- Поведение (без физики и коллизий) ---
    @Override
    public boolean method_5863() { return false; }

    @Override
    public boolean method_5810() { return false; }

    @Override
    public boolean method_5740() { return true; }

    @Override
    public void method_5697(class_1297 entity) {}
    @Override
    public void method_5762(double x, double y, double z) {}

    @Override
    public void method_5773() {
        // Без вызова super.tick() — никаких авто‑движений
        if (!this.method_37908().field_9236 && this.platePos != null) {
            if (!(this.method_37908().method_8320(this.platePos).method_26204() instanceof Plate)) {
                this.method_31472();
            }
        }
    }

    // --- Сохранение (platePos в NBT) ---
    @Override
    public void method_5749(class_2487 tag) {
        if (tag.method_10545("Item")) {
            class_1799 itemstack = class_1799.method_57360(this.method_56673(), tag.method_10562("Item")).orElse(class_1799.field_8037);
            this.setItem(itemstack);
        }
        if (tag.method_10545("Rotation")) {
            this.setRotation(tag.method_10550("Rotation"));
        }
        if (tag.method_10545("PlatePos")) {
            this.platePos = class_2338.method_10092(tag.method_10537("PlatePos"));
        }
    }

    @Override
    public void method_5652(class_2487 tag) {
        if (!this.getItem().method_7960()) {
            class_2487 itemTag = new class_2487();
            this.getItem().method_57376(this.method_56673(), itemTag);
            tag.method_10566("Item", itemTag);
        }
        tag.method_10569("Rotation", this.getRotation());
        if (this.platePos != null) {
            tag.method_10544("PlatePos", this.platePos.method_10063());
        }
    }

    // --- Дроп при разрушении ---
    public void dropItem() {
        if (!this.getItem().method_7960()) {
            class_1542 itemEntity = new class_1542(
                    this.method_37908(),
                    this.method_23317(), this.method_23318() + 0.1, this.method_23321(),
                    this.getItem().method_7972()
            );
            itemEntity.method_6988();
            this.method_37908().method_8649(itemEntity);
            this.setItem(class_1799.field_8037);
        }
    }

    @Override
    public void method_5650(class_5529 reason) {
        if (!this.method_37908().field_9236 && reason.method_31486()) {
            this.dropItem();
        }
        super.method_5650(reason);
    }
}