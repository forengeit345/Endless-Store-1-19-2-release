package net.es.block.custom;

import com.mojang.serialization.MapCodec;
import net.es.entity.PlateEntity;
import net.minecraft.class_10;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_9062;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

public class Plate extends class_2248 {
    public static final MapCodec<Plate> CODEC = method_54094(Plate::new);
    public static final class_2753 FACING = class_2741.field_12481;
    private static final class_265 SHAPE = class_2248.method_9541(5, 0, 4.85, 11.3, 0.39, 11.15);

    public Plate(class_2251 properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969() {
        return field_46280;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    protected boolean method_9516(class_2680 state, class_10 pathComputationType) {
        return true;
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        return method_20044(level, pos.method_10074(), class_2350.field_11036);
    }

    @Override
    protected class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState,
                                     class_1936 level, class_2338 pos, class_2338 neighborPos) {
        return direction == class_2350.field_11033 && !this.method_9558(state, level, pos)
                ? class_2246.field_10124.method_9564()
                : super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    public void method_9615(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState, boolean movedByPiston) {
        if (!level.field_9236 && !oldState.method_27852(state.method_26204())) {
            class_2350 facing = state.method_11654(FACING);
            PlateEntity plateEntity = new PlateEntity(level, pos, facing);
            level.method_8649(plateEntity);
        }
    }

    @Override
    public void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean movedByPiston) {
        if (!state.method_27852(newState.method_26204())) {
            level.method_18467(PlateEntity.class, new class_238(pos)).forEach(class_1297::method_31472);
        }
        super.method_9536(state, level, pos, newState, movedByPiston);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
        if (!level.field_9236) {
            level.method_18467(PlateEntity.class, new class_238(pos)).stream()
                    .findFirst()
                    .ifPresent(plate -> plate.method_5688(player, class_1268.field_5808));
        }
        return class_1269.method_29236(level.field_9236);
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        if (!level.field_9236) {
            level.method_18467(PlateEntity.class, new class_238(pos)).stream()
                    .findFirst()
                    .ifPresent(plate -> plate.method_5688(player, hand));
        }
        return class_9062.method_55644(level.field_9236);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }
}