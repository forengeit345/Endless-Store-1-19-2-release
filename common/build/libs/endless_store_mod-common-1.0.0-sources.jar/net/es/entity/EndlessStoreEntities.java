package net.es.entity;

import java.util.function.Supplier;
import net.minecraft.class_1299;

public class EndlessStoreEntities {
    public static Supplier<class_1299<PlateEntity>> PLATE = () -> {
        throw new IllegalStateException("PlateEntity type not initialized");
    };

    public static void init() {}
}