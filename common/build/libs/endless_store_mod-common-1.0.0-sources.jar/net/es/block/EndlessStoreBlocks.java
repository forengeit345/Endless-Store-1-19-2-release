package net.es.block;

import net.es.EndlessStoreMod;
import net.es.block.custom.*;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2577;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_7923;
import net.minecraft.world.level.block.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

public class EndlessStoreBlocks {
    public static final Map<String, Supplier<class_2248>> BLOCK_FACTORIES = new LinkedHashMap<>();

    public static final String CONCRETE = "concrete";
    public static final String DARK_CONCRETE = "dark_concrete";
    public static final String WHITE_BRICK = "white_brick";
    public static final String WHITE_BRICK_ALTERNATIVE = "white_brick_alternative";
    public static final String BEDSIDE_TABLE = "bedside_table";
    public static final String CARDBOARD_BOX_HUGE_TAPE = "cardboard_box_huge_tape";
    public static final String CONCRETE_FURNACE = "concrete_furnace";
    public static final String PLATE = "plate";
    public static final String OLD_SAFE = "old_safe";

    static {
        BLOCK_FACTORIES.put("laminate_flooring_light", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15996).method_9626(class_2498.field_11547).method_9632(1.15f)));
        BLOCK_FACTORIES.put("laminate_flooring_light_vertical", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15996).method_9626(class_2498.field_11547).method_9632(1.15f)));
        BLOCK_FACTORIES.put("laminate_flooring_dark", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15996).method_9626(class_2498.field_11547).method_9632(1.15f)));
        BLOCK_FACTORIES.put("laminate_flooring_mangrove", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16030).method_9626(class_2498.field_11547).method_9632(1.15f)));
        BLOCK_FACTORIES.put("laminate_flooring_white", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11547).method_9632(1.15f)));

        BLOCK_FACTORIES.put("plitka_water", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16026).method_9626(class_2498.field_11544).method_9632(1.8f).method_29292()));

        BLOCK_FACTORIES.put("concrete", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11544).method_9632(2.5f).method_29292()));

        BLOCK_FACTORIES.put("mossy_concrete", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15995).method_9626(class_2498.field_11544).method_9632(2f).method_29292()));
        BLOCK_FACTORIES.put("overgrown_concrete", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15995).method_9626(class_2498.field_11544).method_9632(1.9f).method_29292()));
        BLOCK_FACTORIES.put("dark_mossy_concrete", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15995).method_9626(class_2498.field_11544).method_9632(2f).method_29292()));
        BLOCK_FACTORIES.put("dark_overgrown_concrete", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16028).method_9626(class_2498.field_11544).method_9632(1.9f).method_29292()));
        BLOCK_FACTORIES.put("dark_cracked_concrete", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16028).method_9626(class_2498.field_11544).method_9632(1.75f).method_29292()));

        BLOCK_FACTORIES.put("dark_concrete", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16009).method_9626(class_2498.field_11544).method_9632(2.5f).method_29292()));

        BLOCK_FACTORIES.put("concrete_slab", () -> new class_2482(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11544).method_9632(2.5f).method_29292()));
        BLOCK_FACTORIES.put("concrete_stairs", () -> new CustomStairsBlock(getBaseBlockState(CONCRETE), class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11544).method_9632(2.5f).method_29292()));

        BLOCK_FACTORIES.put("dark_concrete_slab", () -> new class_2482(class_2248.Properties.method_9637().method_31710(class_3620.field_16009).method_9626(class_2498.field_11544).method_9632(2.5f).method_29292()));
        BLOCK_FACTORIES.put("dark_concrete_stairs", () -> new CustomStairsBlock(getBaseBlockState(DARK_CONCRETE), class_2248.Properties.method_9637().method_31710(class_3620.field_16009).method_9626(class_2498.field_11544).method_9632(2.5f).method_29292()));

        BLOCK_FACTORIES.put("yellow_concrete", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16013).method_9626(class_2498.field_11544).method_9632(2.5f).method_29292()));

        BLOCK_FACTORIES.put("orange_granit", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15981).method_9626(class_2498.field_11544).method_9632(1.5f).method_29292()));

        BLOCK_FACTORIES.put("white_brick", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11544).method_9632(3f).method_29292()));
        BLOCK_FACTORIES.put("white_brick_alternative", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11544).method_9632(3f).method_29292()));

        BLOCK_FACTORIES.put("white_brick_stairs_es", () -> new CustomStairsBlock(getBaseBlockState(WHITE_BRICK), class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11544).method_9632(3f).method_29292()));
        BLOCK_FACTORIES.put("white_brick_stairs_alternative", () -> new CustomStairsBlock(getBaseBlockState(WHITE_BRICK_ALTERNATIVE), class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11544).method_9632(3f).method_29292()));

        BLOCK_FACTORIES.put("white_brick_slab", () -> new class_2482(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11544).method_9632(3f).method_29292()));
        BLOCK_FACTORIES.put("white_brick_slab_alternative", () -> new class_2482(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11544).method_9632(3f).method_29292()));

        BLOCK_FACTORIES.put("linoleum_light", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15996).method_9626(class_2498.field_11547).method_9632(1.2f).method_29292()));
        BLOCK_FACTORIES.put("linoleum_brown", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15996).method_9626(class_2498.field_11547).method_9632(1.2f).method_29292()));

        BLOCK_FACTORIES.put("wallpaper_yellow", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11547).method_9632(0.65f)));
        BLOCK_FACTORIES.put("wallpaper_white", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11547).method_9632(0.65f)));
        BLOCK_FACTORIES.put("wallpaper_blue", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16024).method_9626(class_2498.field_11547).method_9632(0.65f)));

        BLOCK_FACTORIES.put("metal_garage_door", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11533).method_9632(2.6f).method_29292()));

        BLOCK_FACTORIES.put("patterned_carpet", () -> new class_2577(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11543).method_9632(1f)));

        BLOCK_FACTORIES.put("plastic_garbage_colored", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15978).method_9626(class_2498.field_11544).method_9632(1f)));
        BLOCK_FACTORIES.put("plastic_garbage_grey", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11544).method_9632(1f)));
        BLOCK_FACTORIES.put("plastic_garbage_blue", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15983).method_9626(class_2498.field_11544).method_9632(1f)));

        BLOCK_FACTORIES.put("concrete_furnace", () -> new CustomFurnaceBlock(class_2248.Properties.method_9637()
                .method_31710(class_3620.field_16023).method_9626(class_2498.field_11544).method_9632(3.5F).method_29292()
                .method_9631(state -> state.method_11654(CustomFurnaceBlock.field_11105) ? 13 : 0)));

        BLOCK_FACTORIES.put("ceiling_tiles_white", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15988).method_9626(class_2498.field_11544).method_9632(3f).method_29292()));

        BLOCK_FACTORIES.put("concrete_mud", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16000).method_9626(class_2498.field_28700).method_9632(2.25f).method_29292()));
        BLOCK_FACTORIES.put("probably_mud", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15977).method_9626(class_2498.field_37640).method_9632(1.25f)));
        BLOCK_FACTORIES.put("chain_mail", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16005).method_9626(class_2498.field_24119).method_9632(3f).method_29292().method_22488()));
        BLOCK_FACTORIES.put("green_mud", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16028).method_9626(class_2498.field_11545).method_9632(2.25f).method_29292()));
        BLOCK_FACTORIES.put("lime_mud", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15995).method_9626(class_2498.field_11545).method_9632(2.25f).method_29292()));

        BLOCK_FACTORIES.put("laminate_flooring_dark_damaged", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15996).method_9626(class_2498.field_11547).method_9632(1.05f).method_29292()));
        BLOCK_FACTORIES.put("laminate_flooring_light_damaged", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15996).method_9626(class_2498.field_11547).method_9632(1.05f).method_29292()));
        BLOCK_FACTORIES.put("laminate_flooring_mangrove_damaged", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16030).method_9626(class_2498.field_11547).method_9632(1.05f).method_29292()));
        BLOCK_FACTORIES.put("laminate_flooring_white_damaged", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11547).method_9632(1.05f).method_29292()));
        BLOCK_FACTORIES.put("wallpaper_blue_damaged", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16024).method_9626(class_2498.field_11547).method_9632(0.55f).method_29292()));
        BLOCK_FACTORIES.put("wallpaper_white_damaged", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11547).method_9632(0.55f).method_29292()));
        BLOCK_FACTORIES.put("wallpaper_yellow_damaged", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11547).method_9632(0.55f).method_29292()));
        BLOCK_FACTORIES.put("white_brick_damaged", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11544).method_9632(2.8f).method_29292()));
        BLOCK_FACTORIES.put("white_brick_mossy", () -> new class_2248(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11544).method_9632(2.5f).method_29292()));

        BLOCK_FACTORIES.put("metal_pipe", () -> new MetalPipe(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11533).method_9632(2f).method_29292()));
        BLOCK_FACTORIES.put("metal_corner_pipe", () -> new MetalCornerPipe(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11533).method_9632(2f).method_29292()));
        BLOCK_FACTORIES.put("shelves", () -> new ShelvesProp(class_2248.Properties.method_9637().method_31710(class_3620.field_15977).method_9626(class_2498.field_11547).method_9632(1.75f).method_22488()));
        BLOCK_FACTORIES.put("baseboard", () -> new Baseboard(class_2248.Properties.method_9637().method_31710(class_3620.field_15977).method_9626(class_2498.field_11547).method_9632(0.6f)));
        BLOCK_FACTORIES.put("baseboard_corner", () -> new BaseboardCorner(class_2248.Properties.method_9637().method_31710(class_3620.field_15977).method_9626(class_2498.field_11547).method_9632(0.6f)));
        BLOCK_FACTORIES.put("plush_mouse_graf", () -> new PlushMouseGraf(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11543).method_9632(0.5f)));
        BLOCK_FACTORIES.put("outdoor_sign", () -> new OutdoorSign(class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11547).method_9632(0.65f)));
        BLOCK_FACTORIES.put("fire_crane", () -> new FireCrane(class_2248.Properties.method_9637().method_31710(class_3620.field_15982).method_9626(class_2498.field_11533).method_9632(1.25f).method_22488()));
        BLOCK_FACTORIES.put("kettle", () -> new Kettle(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11533).method_9632(0.5f)));
        BLOCK_FACTORIES.put("wall_clock", () -> new WallClock(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11533).method_9632(0.5f)));
        BLOCK_FACTORIES.put("pallet", () -> new Pallet(class_2248.Properties.method_9637().method_31710(class_3620.field_15996).method_9626(class_2498.field_11547).method_9632(1.45f).method_22488()));
        BLOCK_FACTORIES.put("fire_detector", () -> new FireDetector(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11533).method_9632(0.9f)));
        BLOCK_FACTORIES.put("wall_map", () -> new WallMap(class_2248.Properties.method_9637().method_31710(class_3620.field_16024).method_9626(class_2498.field_11544).method_9632(0.5f)));
        BLOCK_FACTORIES.put("cargo_trolley", () -> new CargoTrolley(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11533).method_9632(2.6f).method_29292()));
        BLOCK_FACTORIES.put("cargo_trolley_long_one_handles", () -> new CargoTrolleyLong(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11533).method_9632(2.6f).method_29292().method_22488()));
        BLOCK_FACTORIES.put("cargo_trolley_long_two_handles", () -> new CargoTrolleyLong(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11533).method_9632(2.6f).method_29292().method_22488()));
        BLOCK_FACTORIES.put("book_variant_one", () -> new BookVariantOne(class_2248.Properties.method_9637().method_31710(class_3620.field_15995).method_9626(class_2498.field_11544).method_9632(0.8f)));
        BLOCK_FACTORIES.put("book_variant_two", () -> new BookVariantTwo(class_2248.Properties.method_9637().method_31710(class_3620.field_15995).method_9626(class_2498.field_11544).method_9632(0.8f)));
        BLOCK_FACTORIES.put("book_variant_three", () -> new BookVariantThree(class_2248.Properties.method_9637().method_31710(class_3620.field_15995).method_9626(class_2498.field_11544).method_9632(0.8f)));
        BLOCK_FACTORIES.put("armchair", () -> new Armchair(class_2248.Properties.method_9637().method_31710(class_3620.field_15996).method_9626(class_2498.field_11543).method_9632(4.1f).method_22488()));
        BLOCK_FACTORIES.put("wardrobe", () -> new Wardrobe(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11547).method_9632(4.5f)));
        BLOCK_FACTORIES.put("big_wardrobe", () -> new BigWardrobe(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11547).method_9632(3.5f).method_22488()));
        BLOCK_FACTORIES.put("cardboard_box", () -> new CardboardBox(class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11547).method_9632(0.7f)));
        BLOCK_FACTORIES.put("cardboard_box_open", () -> new CardboardBox(class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11547).method_9632(0.4f)));
        BLOCK_FACTORIES.put("cardboard_box_middle", () -> new CardboardBoxMiddle(class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11547).method_9632(0.8f)));
        BLOCK_FACTORIES.put("cardboard_box_middle_open", () -> new CardboardBoxMiddle(class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11547).method_9632(0.5f)));
        BLOCK_FACTORIES.put("cardboard_box_large", () -> new CardboardBoxLarge(class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11547).method_9632(1f)));
        BLOCK_FACTORIES.put("cardboard_box_large_open", () -> new CardboardBoxLarge(class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11547).method_9632(0.7f)));
        BLOCK_FACTORIES.put("cardboard_box_huge", () -> new CardboardBoxHuge(class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11547).method_9632(1.5f).method_22488()));
        BLOCK_FACTORIES.put("cardboard_box_huge_open", () -> new CardboardBoxHuge(class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11547).method_9632(1f).method_22488()));
        BLOCK_FACTORIES.put("cardboard_box_huge_tape", () -> new CardboardBoxHugeTape(class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11547).method_9632(1.5f).method_22488()));
        BLOCK_FACTORIES.put("trash_can", () -> new TrashCan(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11544).method_9632(1.25f).method_29292()));
        BLOCK_FACTORIES.put("plate", () -> new Plate(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11544).method_9632(0.4f)));
        BLOCK_FACTORIES.put("fuse_box", () -> new FuseBox(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11533).method_9632(1.35f)));
        BLOCK_FACTORIES.put("fuse_box_large", () -> new FuseBoxLarge(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11533).method_9632(1.65f)));
        BLOCK_FACTORIES.put("toolbox", () -> new Toolbox(class_2248.Properties.method_9637().method_31710(class_3620.field_15982).method_9626(class_2498.field_11533).method_9632(0.6f)));
        BLOCK_FACTORIES.put("coil_wires", () -> new CoilWires(class_2248.Properties.method_9637().method_31710(class_3620.field_15982).method_9626(class_2498.field_11533).method_9632(1.1f)));
        BLOCK_FACTORIES.put("wooden_chair", () -> new WoodenChair(class_2248.Properties.method_9637().method_31710(class_3620.field_15982).method_9626(class_2498.field_11533).method_9632(1.1f)));
        BLOCK_FACTORIES.put("wooden_table", () -> new AbstractTable(class_2248.Properties.method_9637().method_31710(class_3620.field_15996).method_9626(class_2498.field_11547).method_9632(2f).method_22488()));
        BLOCK_FACTORIES.put("wooden_table_long", () -> new AbstractTableLong(class_2248.Properties.method_9637().method_31710(class_3620.field_15996).method_9626(class_2498.field_11547).method_9632(2.4f).method_22488()));
        BLOCK_FACTORIES.put("plastic_table", () -> new AbstractTable(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11544).method_9632(1.8f).method_22488()));
        BLOCK_FACTORIES.put("plastic_table_long", () -> new AbstractTableLong(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11544).method_9632(2f).method_22488()));
        BLOCK_FACTORIES.put("towel_holder", () -> new TowelHolder(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11533).method_9632(1f)));
        BLOCK_FACTORIES.put("padded_stool", () -> new PaddedStool(class_2248.Properties.method_9637().method_31710(class_3620.field_15977).method_9626(class_2498.field_11543).method_9632(2.1f).method_22488()));
        BLOCK_FACTORIES.put("mirror", () -> new Mirror(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11537).method_9632(0.8f)));
        BLOCK_FACTORIES.put("high_mirror", () -> new HighMirror(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11537).method_9632(1f)));
        BLOCK_FACTORIES.put("radiator_right_side", () -> new Radiator(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11533).method_9632(1.8f).method_29292()));
        BLOCK_FACTORIES.put("radiator_left_side", () -> new Radiator(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11533).method_9632(1.8f).method_29292()));
        BLOCK_FACTORIES.put("square_shelf", () -> new SquareShelf(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11547).method_9632(1.45f)));
        BLOCK_FACTORIES.put("sink", () -> new Sink(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11544).method_9632(2f).method_29292().method_22488()));
        BLOCK_FACTORIES.put("socket", () -> new Socket(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11533).method_9632(1.1f)));
        BLOCK_FACTORIES.put("side_pipes", () -> new SidePipes(class_2248.Properties.method_9637().method_31710(class_3620.field_16005).method_9626(class_2498.field_11533).method_9632(1.8f).method_29292()));
        BLOCK_FACTORIES.put("ceiling_pipes", () -> new CeilingPipes(class_2248.Properties.method_9637().method_31710(class_3620.field_16005).method_9626(class_2498.field_11533).method_9632(1.8f).method_29292()));
        BLOCK_FACTORIES.put("pedestal_altea", () -> new PedestalAltea(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11547).method_9632(2f)));
        BLOCK_FACTORIES.put("metal_closet", () -> new MetalCloset(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11533).method_9632(3.75f).method_29292().method_22488()));
        BLOCK_FACTORIES.put("white_bookshelf", () -> new WhiteBookshelf(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11547).method_9632(1.45f)));
        BLOCK_FACTORIES.put("calendar", () -> new Calendar(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11544).method_9632(0.5f)));
        BLOCK_FACTORIES.put("decorative_fence", () -> new DecorativeFence(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11533).method_9632(0.65f)));
        BLOCK_FACTORIES.put("practical_fence", () -> new PracticalFence(class_2248.Properties.method_9637().method_31710(class_3620.field_16005).method_9626(class_2498.field_11533).method_9632(2.5f).method_29292()));
        BLOCK_FACTORIES.put("plastic_chair", () -> new PlasticChair(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11544).method_9632(2.2f)));
        BLOCK_FACTORIES.put("vertical_washing_machine", () -> new VerticalWashingMachine(class_2248.Properties.method_9637().method_31710(class_3620.field_16007).method_9626(class_2498.field_11533).method_9632(3.85f).method_29292()));
        BLOCK_FACTORIES.put("bedside_table", () -> new BedsideTable(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11547).method_9632(2.2f)));
        BLOCK_FACTORIES.put("globe", () -> new Globe(class_2248.Properties.method_9637().method_31710(class_3620.field_16024).method_9626(class_2498.field_11547).method_9632(0.5f)));
        BLOCK_FACTORIES.put("aquarium", () -> new Aquarium(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11537).method_9632(1.25f).method_22488()));
        BLOCK_FACTORIES.put("mre", () -> new MRE(class_2248.Properties.method_9637().method_31710(class_3620.field_15995).method_9626(class_2498.field_11542).method_9632(0.5f)));
        BLOCK_FACTORIES.put("bottle", () -> new Bottle(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11537).method_9632(0.5f)));
        BLOCK_FACTORIES.put("safe", () -> new Safe(class_2248.Properties.method_9637().method_31710(class_3620.field_16005).method_9626(class_2498.field_11533).method_9632(5.5f).method_29292()));
        BLOCK_FACTORIES.put("ceiling_grid", () -> new CeilingGrid(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11533).method_9632(2f).method_29292().method_22488()));
        BLOCK_FACTORIES.put("side_storage_shelves", () -> new SideStorageShelves(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11533).method_9632(2f).method_29292().method_22488()));
        BLOCK_FACTORIES.put("side_beams", () -> new SideBeams(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11533).method_9632(2f).method_29292().method_22488()));
//        BLOCK_FACTORIES.put("computer", () -> new Computer(Block.Properties.of().mapColor(MapColor.COLOR_LIGHT_GRAY).sound(SoundType.METAL).strength(1.5f).requiresCorrectToolForDrops()));
        BLOCK_FACTORIES.put("old_safe", () -> new OldSafe(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11533).method_9629(-1.0F, 3600000.0F).method_42327()));
        BLOCK_FACTORIES.put("vertical_boiler", () -> new VerticalBoiler(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11533).method_9632(3.75f).method_29292()));
        BLOCK_FACTORIES.put("horizontal_boiler", () -> new HorizontalBoiler(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11533).method_9632(3.75f).method_29292()));
        BLOCK_FACTORIES.put("organizer", () -> new Organizer(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11547).method_9632(0.5f)));
        BLOCK_FACTORIES.put("empty_organizer", () -> new Organizer(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11547).method_9632(0.5f)));
        BLOCK_FACTORIES.put("small_wooden_barricades", () -> new WoodenBarricades(class_2248.Properties.method_9637().method_31710(class_3620.field_15996).method_9626(class_2498.field_11547).method_9632(1.0f).method_29292().method_22488()));
        BLOCK_FACTORIES.put("medium_wooden_barricades", () -> new WoodenBarricades(class_2248.Properties.method_9637().method_31710(class_3620.field_15996).method_9626(class_2498.field_11547).method_9632(1.5f).method_29292().method_22488()));
        BLOCK_FACTORIES.put("large_wooden_barricades", () -> new WoodenBarricades(class_2248.Properties.method_9637().method_31710(class_3620.field_15996).method_9626(class_2498.field_11547).method_9632(2.0f).method_29292().method_22488()));
        BLOCK_FACTORIES.put("mud_on_floor", () -> new GarbageOnFloor(class_2248.Properties.method_9637().method_22488().method_9634().method_42327().method_22488()));
        BLOCK_FACTORIES.put("garbage_on_floor", () -> new GarbageOnFloor(class_2248.Properties.method_9637().method_51371().method_9634().method_42327().method_22488()));
        BLOCK_FACTORIES.put("concrete_crumbs_on_floor", () -> new GarbageOnFloor(class_2248.Properties.method_9637().method_51371().method_9634().method_42327().method_22488()));
        BLOCK_FACTORIES.put("water_strider_egg", () -> new WaterStriderEgg(class_2248.Properties.method_9637().method_31710(class_3620.field_15995).method_9626(class_2498.field_11545).method_9632(0.5f).method_22488()));
        BLOCK_FACTORIES.put("water_strider_egg_middle", () -> new WaterStriderEgg(class_2248.Properties.method_9637().method_31710(class_3620.field_15995).method_9626(class_2498.field_11545).method_9632(0.5f).method_22488()));
        BLOCK_FACTORIES.put("water_strider_egg_large", () -> new WaterStriderEgg(class_2248.Properties.method_9637().method_31710(class_3620.field_15995).method_9626(class_2498.field_11545).method_9632(0.5f).method_22488()));
        BLOCK_FACTORIES.put("water_strider_egg_huge", () -> new WaterStriderEgg(class_2248.Properties.method_9637().method_31710(class_3620.field_15995).method_9626(class_2498.field_11545).method_9632(0.5f).method_22488()));
        BLOCK_FACTORIES.put("painting_horizontal_forest", () -> new PaintingHorizontal(class_2248.Properties.method_9637().method_9626(class_2498.field_40313).method_9632(1f)));
        BLOCK_FACTORIES.put("painting_horizontal_sunset", () -> new PaintingHorizontal(class_2248.Properties.method_9637().method_9626(class_2498.field_40313).method_9632(1f)));
        BLOCK_FACTORIES.put("painting_horizontal_emptiness", () -> new PaintingHorizontal(class_2248.Properties.method_9637().method_9626(class_2498.field_40313).method_9632(1f)));
        BLOCK_FACTORIES.put("painting_vertical_lake", () -> new PaintingVertical(class_2248.Properties.method_9637().method_9626(class_2498.field_40313).method_9632(1f)));
        BLOCK_FACTORIES.put("painting_vertical_city", () -> new PaintingVertical(class_2248.Properties.method_9637().method_9626(class_2498.field_40313).method_9632(1f)));
        BLOCK_FACTORIES.put("painting_vertical_pipes", () -> new PaintingVertical(class_2248.Properties.method_9637().method_9626(class_2498.field_40313).method_9632(1f)));
        BLOCK_FACTORIES.put("filing_cabinet_closed", () -> new FilingCabinet(class_2248.Properties.method_9637().method_9626(class_2498.field_11547).method_9632(1.5f).method_29292()));
        BLOCK_FACTORIES.put("filing_cabinet_open_up", () -> new FilingCabinet(class_2248.Properties.method_9637().method_9626(class_2498.field_11547).method_9632(1.5f).method_29292()));
        BLOCK_FACTORIES.put("filing_cabinet_open_down", () -> new FilingCabinet(class_2248.Properties.method_9637().method_9626(class_2498.field_11547).method_9632(1.5f).method_29292()));
        BLOCK_FACTORIES.put("showcase_with_dishes", () -> new ShowcaseWithDishes(class_2248.Properties.method_9637().method_31710(class_3620.field_16023).method_9626(class_2498.field_11533).method_9632(2f).method_29292().method_22488()));
    }

    private static class_2680 getBaseBlockState(String blockName) {
        return class_7923.field_41175
                .method_10223(class_2960.method_60655(EndlessStoreMod.MOD_ID, blockName))
                .method_9564();
    }

    @FunctionalInterface
    public interface BlockRegisterer {
        Supplier<class_2248> register(String name, Supplier<class_2248> blockFactory);
    }

    @FunctionalInterface
    public interface ModItemRegisterer {
        void register(String name, Supplier<class_1792> itemFactory);
    }

    public static void registerBlocks(BlockRegisterer blockRegistry, ModItemRegisterer itemRegistry) {
        BLOCK_FACTORIES.forEach((name, blockFactory) -> {
            Supplier<class_2248> registeredBlockSupplier = blockRegistry.register(name, blockFactory);
            itemRegistry.register(name, () -> new class_1747(registeredBlockSupplier.get(), new class_1792.class_1793()));
        });
    }
}