package net.es.entity;

import net.minecraft.world.entity.EntityType;

import java.util.function.Supplier;

public class EndlessStoreEntities {
    public static Supplier<EntityType<PlateEntity>> PLATE = () -> {
        throw new IllegalStateException("PlateEntity type not initialized");
    };

    public static void init() {}
}