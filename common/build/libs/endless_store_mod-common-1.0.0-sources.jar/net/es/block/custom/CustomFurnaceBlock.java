package net.es.block.custom;

import com.mojang.serialization.MapCodec;
import net.es.block.entity.CustomFurnaceBlockEntity;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2363;
import net.minecraft.class_2398;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3908;
import net.minecraft.class_4970;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;

public class CustomFurnaceBlock extends class_2363 {
    public static final MapCodec<CustomFurnaceBlock> CODEC = method_54094(CustomFurnaceBlock::new);

    public static Supplier<class_2591<CustomFurnaceBlockEntity>> TYPE = () -> {
        throw new IllegalStateException("CustomFurnaceBlock type not initialized");
    };

    public CustomFurnaceBlock(class_4970.class_2251 properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends class_2363> method_53969() {
        return field_46280;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new CustomFurnaceBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type) {
        return method_31617(level, type, TYPE.get());
    }

    @Override
    protected void method_17025(class_1937 level, class_2338 pos, class_1657 player) {
        class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof CustomFurnaceBlockEntity) {
            player.method_17355((class_3908) blockEntity);
            player.method_7281(class_3468.field_15379);
        }
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        if (state.method_11654(field_11105)) {
            double d = (double) pos.method_10263() + 0.5;
            double e = (double) pos.method_10264();
            double f = (double) pos.method_10260() + 0.5;
            if (random.method_43058() < 0.1) {
                level.method_8486(d, e, f, class_3417.field_15006, class_3419.field_15245, 1.0F, 1.0F, false);
            }

            class_2350 direction = state.method_11654(field_11104);
            class_2350.class_2351 axis = direction.method_10166();
            double g = 0.52;
            double h = random.method_43058() * 0.6 - 0.3;
            double i = axis == class_2350.class_2351.field_11048 ? (double) direction.method_10148() * 0.52 : h;
            double j = random.method_43058() * 6.0 / 16.0;
            double k = axis == class_2350.class_2351.field_11051 ? (double) direction.method_10165() * 0.52 : h;
            level.method_8406(class_2398.field_11251, d + i, e + j, f + k, 0.0, 0.0, 0.0);
            level.method_8406(class_2398.field_11240, d + i, e + j, f + k, 0.0, 0.0, 0.0);
        }
    }
}