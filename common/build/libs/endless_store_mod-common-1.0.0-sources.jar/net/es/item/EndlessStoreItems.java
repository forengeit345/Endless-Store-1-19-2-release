package net.es.item;

import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_1834;
import net.minecraft.class_1856;
import net.minecraft.class_2248;
import net.minecraft.class_3481;
import net.minecraft.class_3612;
import net.minecraft.class_4174;
import net.minecraft.class_6862;
import net.minecraft.world.item.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

public class EndlessStoreItems {
    public static final Map<String, Supplier<class_1792>> FACTORIES = new LinkedHashMap<>();

    public static Supplier<class_1792> PLASTIC_BUCKET_ITEM = () -> {
        throw new IllegalStateException("Plastic bucket not registered");
    };


    // --- Идентификаторы предметов ---
    public static final String WOODEN_BOARD = "wooden_board";
    public static final String PLASTIC_BUCKET = "plastic_bucket";

    public static final String EMPLOYEE_SPAWN_EGG = "employee_spawn_egg";
    public static final String JACK_SPAWN_EGG = "jack_spawn_egg";
    public static final String SECURITY_SPAWN_EGG = "security_spawn_egg";
    public static final String WATCHER_SPAWN_EGG = "watcher_spawn_egg";
    public static final String WATER_STRIDER_EGG = "water_strider_spawn_egg";
    public static final String KNIFE = "knife";
    public static final String FRYING_PAN = "frying_pan";
    public static final String BATON = "baton";
    public static final String EXTINGUISHER = "extinguisher";
    public static final String EMPLOYEES_SHIRT = "employees_shirt";
    public static final String SECURITY_CAP = "security_cap";
    public static final String CARDBOARD_HELMET = "cardboard_helmet";
    public static final String CARDBOARD_TROUSERS = "cardboard_trousers";
    public static final String HANDMADE_CHAIN_MAIL = "handmade_chain_mail";
    public static final String HANDMADE_CHAIN_MAIL_TROUSERS = "handmade_chain_mail_trousers";
    public static final String SECURITY_SHIRT = "security_shirt";

    private static final class_1832 KNIFE_TIER = new class_1832() {
        @Override public int method_8025() { return 59; }
        @Override public float method_8027() { return 2.0F; }
        @Override public float method_8028() { return 2.0F; }
        @Override public int method_8026() { return 15; }
        @Override public class_1856 method_8023() { return class_1856.method_8091(class_1802.field_8118); }
        @Override public class_6862<class_2248> method_58419() {
            return class_3481.field_49930;  // для деревянного инструмента
        }
    };

    private static final class_1832 FRYING_PAN_TIER = new class_1832() {
        @Override public int method_8025() { return 250; }
        @Override public float method_8027() { return 6.0F; }
        @Override public float method_8028() { return 3.0F; }
        @Override public int method_8026() { return 14; }
        @Override public class_1856 method_8023() { return class_1856.method_8091(class_1802.field_8620); }
        @Override public class_6862<class_2248> method_58419() {
            return class_3481.field_49927;    // для железного инструмента
        }
    };
    private static final class_1832 BATON_TIER = new class_1832() {
        @Override public int method_8025() { return 250; }          // как IRON
        @Override public float method_8027() { return 6.0F; }
        @Override public float method_8028() { return 3.0F; }  // 6 – 3 = 3
        @Override public int method_8026() { return 14; }
        @Override public class_1856 method_8023() { return class_1856.method_8091(class_1802.field_8620); }
        @Override public class_6862<class_2248> method_58419() {
            return class_3481.field_49927;    // для железного инструмента
        }
    };

    private static final class_1832 EXTINGUISHER_TIER = new class_1832() {
        @Override public int method_8025() { return 131; }          // как STONE
        @Override public float method_8027() { return 4.0F; }
        @Override public float method_8028() { return 5.0F; }  // 8 – 3 = 5
        @Override public int method_8026() { return 5; }
        @Override public class_1856 method_8023() { return class_1856.method_8091(class_1802.field_20391); }
        @Override public class_6862<class_2248> method_58419() {
            return class_3481.field_49928;    // для железного инструмента
        }
    };

    static {
        // Обычные предметы
        FACTORIES.put("wooden_board", () -> new class_1792(new class_1792.class_1793().method_7889(16)));
        FACTORIES.put("concrete_crumbs", () -> new class_1792(new class_1792.class_1793().method_7889(16)));
        FACTORIES.put("piece_of_cardboard", () -> new class_1792(new class_1792.class_1793().method_7889(32)));
        FACTORIES.put("metal_pipes", () -> new class_1792(new class_1792.class_1793().method_7889(8)));
        FACTORIES.put("nails", () -> new class_1792(new class_1792.class_1793().method_7889(32)));
        FACTORIES.put("bolts", () -> new class_1792(new class_1792.class_1793().method_7889(32)));
        FACTORIES.put("metal_plates", () -> new class_1792(new class_1792.class_1793().method_7889(4)));
        FACTORIES.put("concrete_brick", () -> new class_1792(new class_1792.class_1793().method_7889(16)));
        FACTORIES.put("scrap", () -> new class_1792(new class_1792.class_1793().method_7889(32)));
        FACTORIES.put("molten_scrap", () -> new class_1792(new class_1792.class_1793().method_7889(1)));
        FACTORIES.put("plastic_bucket", () -> new CustomBucketItem(class_3612.field_15906, new class_1792.class_1793().method_7889(16)));
        FACTORIES.put("trash_plastic", () -> new class_1792(new class_1792.class_1793().method_7889(32)));
        FACTORIES.put("broken_glass", () -> new class_1792(new class_1792.class_1793()));
        FACTORIES.put("pieces_of_linoleum", () -> new class_1792(new class_1792.class_1793().method_7889(16)));
        FACTORIES.put("wires", () -> new class_1792(new class_1792.class_1793().method_7889(32)));
        FACTORIES.put("pieces_of_wallpaper", () -> new class_1792(new class_1792.class_1793().method_7889(16)));
        FACTORIES.put("sawdust", () -> new class_1792(new class_1792.class_1793().method_7889(64)));
        FACTORIES.put("coarse_fabric", () -> new class_1792(new class_1792.class_1793().method_7889(16)));
        FACTORIES.put("canister", () -> new class_1792(new class_1792.class_1793().method_7889(4)));
        FACTORIES.put("empty_can", () -> new class_1792(new class_1792.class_1793().method_7889(64)));
        FACTORIES.put("electronic_board", () -> new class_1792(new class_1792.class_1793().method_7889(16)));
        FACTORIES.put("microchip", () -> new class_1792(new class_1792.class_1793().method_7889(64)));
        FACTORIES.put("coil_copper_wires", () -> new class_1792(new class_1792.class_1793().method_7889(16)));
        FACTORIES.put("transistor", () -> new class_1792(new class_1792.class_1793().method_7889(16)));

        // Еда (FoodProperties.Builder)
        FACTORIES.put("brepsi", () -> new class_1792(new class_1792.class_1793().method_19265(new class_4174.class_4175().method_19238(5).method_19237(0.3f).method_19242()).method_7889(4)));
        FACTORIES.put("wet_wallpaper", () -> new class_1792(new class_1792.class_1793().method_19265(new class_4174.class_4175().method_19238(2).method_19237(0.2f).method_19242()).method_7889(16)));
        // StewItem - ваш кастомный класс, позже
//        FACTORIES.put(SAWDUST_SOUP, () -> new StewItem(new Item.Properties()
//                .food(new FoodProperties.Builder().nutrition(7).saturationModifier(0.45f).build())
//                .stacksTo(1)));
        FACTORIES.put("hardtack", () -> new class_1792(new class_1792.class_1793().method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.3f).method_19242()).method_7889(32)));
        FACTORIES.put("crisp", () -> new class_1792(new class_1792.class_1793().method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.2f).method_19242()).method_7889(16)));
        FACTORIES.put("hotdog", () -> new class_1792(new class_1792.class_1793().method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.6F).method_19242()).method_7889(6)));
        FACTORIES.put("pancake", () -> new class_1792(new class_1792.class_1793().method_19265(new class_4174.class_4175().method_19238(3).method_19237(0.6F).method_19242()).method_7889(16)));
        FACTORIES.put("sandwich", () -> new class_1792(new class_1792.class_1793().method_19265(new class_4174.class_4175().method_19238(7).method_19237(0.7f).method_19242()).method_7889(3)));
        FACTORIES.put("water_strider_eggs", () -> new class_1792(new class_1792.class_1793().method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.3f).method_19242()).method_7889(16)));

        // Яйца призыва (SpawnEggItem)
//        FACTORIES.put(EMPLOYEE_SPAWN_EGG, () -> new SpawnEggItem(
//                EndlessStoreEntities.EMPLOYEE, 0x23b341, 0x12732e, new Item.Properties()));
//        FACTORIES.put(JACK_SPAWN_EGG, () -> new SpawnEggItem(
//                EndlessStoreEntities.JACK, 0x83b314, 0x4a732e, new Item.Properties()));
//        FACTORIES.put(SECURITY_SPAWN_EGG, () -> new SpawnEggItem(
//                EndlessStoreEntities.SECURITY, 0x0ebe14, 0x0a3411d, new Item.Properties()));
//        FACTORIES.put(WATCHER_SPAWN_EGG, () -> new SpawnEggItem(
//                EndlessStoreEntities.WATCHER, 0x1dd214, 0x4c6d2ad, new Item.Properties()));
//        FACTORIES.put(WATER_STRIDER_EGG, () -> new SpawnEggItem(
//                EndlessStoreEntities.WATER_STRIDER, 0xade714, 0xcc612ad, new Item.Properties()));

        FACTORIES.put("flimsy_pickaxe", () -> new class_1810(class_1834.field_8922, new class_1792.class_1793().method_7889(1)));
        FACTORIES.put("handmade_pickaxe", () -> new class_1810(class_1834.field_8927, new class_1792.class_1793().method_7889(1)));
        FACTORIES.put("durable_pickaxe", () -> new class_1810(class_1834.field_8923, new class_1792.class_1793().method_7889(1)));
        FACTORIES.put("professional_pickaxe", () -> new class_1810(class_1834.field_8930, new class_1792.class_1793().method_7889(1)));
        FACTORIES.put("handmade_axe", () -> new class_1743(class_1834.field_8927, new class_1792.class_1793().method_7889(1)));
        FACTORIES.put("handmade_shovel", () -> new class_1821(class_1834.field_8927, new class_1792.class_1793().method_7889(1)));

        FACTORIES.put(KNIFE, () -> new class_1829(KNIFE_TIER, new class_1792.class_1793()
                .method_7889(1)
                .method_57348(class_1829.method_57394(KNIFE_TIER, 1, -2.35F))));
        FACTORIES.put(FRYING_PAN, () -> new class_1829(FRYING_PAN_TIER, new class_1792.class_1793()
                .method_7889(1)
                .method_57348(class_1829.method_57394(FRYING_PAN_TIER, 1,-2.8F))));
        FACTORIES.put(BATON, () -> new class_1829(BATON_TIER, new class_1792.class_1793()
                .method_7889(1)
                .method_57348(class_1829.method_57394(BATON_TIER, 1,-2.8F))));
        FACTORIES.put(EXTINGUISHER, () -> new class_1829(EXTINGUISHER_TIER, new class_1792.class_1793()
                .method_7889(1)
                .method_57348(class_1829.method_57394(EXTINGUISHER_TIER, 1,-3.0F))));

        // Инструменты (Tiers вместо ToolMaterials)
//        FACTORIES.put(KNIFE, () -> new SwordItem(
//                Tiers.WOOD, 5, -2.35F, new Item.Properties().stacksTo(1)));
//        FACTORIES.put(FRYING_PAN, () -> new SwordItem(
//                Tiers.IRON, 6, -2.8F, new Item.Properties().stacksTo(1)));
//        FACTORIES.put(BATON, () -> new SwordItem(
//                Tiers.IRON, 6, -2.8F, new Item.Properties().stacksTo(1)));
//        FACTORIES.put(EXTINGUISHER, () -> new SwordItem(
//                Tiers.STONE, 8, -3.0F, new Item.Properties().stacksTo(1)));

        // Броня (ваши кастомные классы, ArmorItem.Type вместо ArmorItem.ArmorSlot)
//        FACTORIES.put(EMPLOYEES_SHIRT, () -> new EmployeeShirtArmorItem(
//                EndlessStoreArmorMaterials.EMPLOYEE, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
//        FACTORIES.put(SECURITY_CAP, () -> new SecurityArmorItem(
//                EndlessStoreArmorMaterials.SECURITY, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
//        FACTORIES.put(CARDBOARD_HELMET, () -> new HandmadeArmorItem(
//                EndlessStoreArmorMaterials.HANDMADE, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
//        FACTORIES.put(CARDBOARD_TROUSERS, () -> new HandmadeArmorItem(
//                EndlessStoreArmorMaterials.HANDMADE, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
//        FACTORIES.put(HANDMADE_CHAIN_MAIL, () -> new HandmadeIronArmorItem(
//                EndlessStoreArmorMaterials.HANDMADE_IRON, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
//        FACTORIES.put(HANDMADE_CHAIN_MAIL_TROUSERS, () -> new HandmadeIronArmorItem(
//                EndlessStoreArmorMaterials.HANDMADE_IRON, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
//        FACTORIES.put(SECURITY_SHIRT, () -> new SecurityArmorItem(
//                EndlessStoreArmorMaterials.SECURITY, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    }

    @FunctionalInterface
    public interface ItemRegistry {
        void register(String name, Supplier<class_1792> factory);
    }

    public static class_1792 getItem(String name) {
        Supplier<class_1792> supplier = FACTORIES.get(name);
        if (supplier == null) {
            throw new IllegalStateException("Item " + name + " not found in FACTORIES");
        }
        return supplier.get();
    }

    public static void registerItems(ItemRegistry registry) {
        FACTORIES.forEach(registry::register);
    }
}