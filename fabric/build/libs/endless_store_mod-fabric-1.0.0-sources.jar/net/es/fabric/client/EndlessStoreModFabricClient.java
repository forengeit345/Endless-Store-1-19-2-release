package net.es.fabric.client;

import net.es.EndlessStoreMod;
import net.es.block.EndlessStoreBlocks;
import net.es.client.renderer.PlateEntityRenderer;
import net.es.entity.EndlessStoreEntities;
import net.es.entity.client.*;
import net.es.fluid.EndlessStoreFluids;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class EndlessStoreModFabricClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        class_2248 chainMail = class_7923.field_41175.method_10223(
                class_2960.method_60655(EndlessStoreMod.MOD_ID, EndlessStoreBlocks.CHAIN_MAIL)
        );
        BlockRenderLayerMap.INSTANCE.putBlock(chainMail, class_1921.method_23581());

        EntityRendererRegistry.register(EndlessStoreEntities.PLATE.get(), PlateEntityRenderer::new);

        FluidRenderHandlerRegistry.INSTANCE.register(
                EndlessStoreFluids.ACID.get(),
                EndlessStoreFluids.FLOWING_ACID.get(),

                new SimpleFluidRenderHandler(
                        class_2960.method_60656("block/water_still"),
                        class_2960.method_60656("block/water_flow"),
                        0xA1E0FFFF
                )
        );

        FluidRenderHandlerRegistry.INSTANCE.register(
                EndlessStoreFluids.WASTE_WATER.get(),
                EndlessStoreFluids.FLOWING_WASTE_WATER.get(),

                new SimpleFluidRenderHandler(
                        class_2960.method_60656("block/water_still"),
                        class_2960.method_60656("block/water_flow"),
                        0xA148D1CC
                )
        );

        ModelLoadingPlugin.register(pluginContext -> {
            pluginContext.addModels(
                    class_2960.method_60655(EndlessStoreMod.MOD_ID, "knife_3d"),
                    class_2960.method_60655(EndlessStoreMod.MOD_ID, "baton_3d"),
                    class_2960.method_60655(EndlessStoreMod.MOD_ID, "frying_pan_3d"),
                    class_2960.method_60655(EndlessStoreMod.MOD_ID, "extinguisher_3d")
            );
        });


        BlockRenderLayerMap.INSTANCE.putFluids(
                class_1921.method_23583(),
                EndlessStoreFluids.ACID.get(),
                EndlessStoreFluids.FLOWING_ACID.get(),
                EndlessStoreFluids.WASTE_WATER.get(),
                EndlessStoreFluids.FLOWING_WASTE_WATER.get()
        );

        EntityRendererRegistry.register(EndlessStoreEntities.EMPLOYEE.get(), EmployeeRenderer::new);
        EntityRendererRegistry.register(EndlessStoreEntities.JACK.get(), JackRenderer::new);
        EntityRendererRegistry.register(EndlessStoreEntities.SECURITY.get(), SecurityRenderer::new);
        EntityRendererRegistry.register(EndlessStoreEntities.WATCHER.get(), WatcherRenderer::new);
        EntityRendererRegistry.register(EndlessStoreEntities.WATER_STRIDER.get(), WaterStriderRenderer::new);
    }
}
