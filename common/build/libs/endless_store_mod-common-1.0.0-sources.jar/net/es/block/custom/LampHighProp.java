package net.es.block.custom;


import com.mojang.serialization.MapCodec;
import net.minecraft.class_10;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

public class LampHighProp extends class_2383 {
    public static final MapCodec<LampHighProp> CODEC = method_54094(LampHighProp::new);

    public static final class_2746 LIT = class_2746.method_11825("lit");
    public LampHighProp(class_2251 properties) {
        super(properties);
    }

//    @Override
//    public ActionResult onUse(BlockState state, World world, BlockPos pos,
//                              PlayerEntity player, Hand hand, BlockHitResult hit) {
//        if (!world.isClient() && hand == Hand.MAIN_HAND) {
//            world.setBlockState(pos, state.cycle(LIT));
//        }
//        return super.onUse(state, world, pos, player, hand, hit);
//    }

    private static final class_265 SHAPE = class_259.method_17786(
            class_2248.method_9541(4, 0, 4, 12, 1.25, 12),
            class_2248.method_9541(7.5, 0, 7.5, 8.75, 20, 8.75),
            class_2248.method_9541(4.5, 20, 4.5, 11.5, 27.25, 11.5)
    );

    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 context) {
        return this.method_9564().method_11657(field_11177, context.method_8042().method_10153());
    }
    @Override
    protected boolean method_9516(class_2680 state, class_10 pathComputationType) {
        return false;
    }

    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(field_11177, rotation.method_10503(state.method_11654(field_11177)));
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(field_11177)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(LIT);
        builder.method_11667(field_11177);
    }
}
