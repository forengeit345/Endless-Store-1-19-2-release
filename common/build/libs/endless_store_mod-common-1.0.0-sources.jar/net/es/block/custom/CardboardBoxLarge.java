package net.es.block.custom;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_10;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3726;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

public class CardboardBoxLarge extends class_2346 {
    public static final MapCodec<CardboardBoxLarge> CODEC = method_54094(CardboardBoxLarge::new);

    public static final class_2753 FACING = class_2741.field_12525;

    public CardboardBoxLarge(class_2251 properties) {
        super(properties);
    }

    private static final class_265 SHAPE = class_2248.method_9541(1.5, 0, 1.4, 14.5, 12.8, 14.4);

    @Override
    protected MapCodec<? extends class_2346> method_53969() {
        return field_46280;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 context) {
        return this.method_9564().method_11657(FACING, context.method_8042().method_10153());
    }
    @Override
    protected boolean method_9516(class_2680 state, class_10 pathComputationType) {
        return false;
    }

    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }
}