package net.es.block.custom;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_10;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

public class HighMirror extends class_2383 {
    public static final MapCodec<HighMirror> CODEC = method_54094(HighMirror::new);

    public HighMirror(class_2251 properties) {
        super(properties);
    }

    private static final class_265 SHAPE_N = class_2248.method_9541(0, 0, 14, 16, 32, 16 );
    private static final class_265 SHAPE_S = class_2248.method_9541(0, 0, 0, 16, 32, 2);
    private static final class_265 SHAPE_W = class_2248.method_9541(14, 0, 0, 16, 32, 16);
    private static final class_265 SHAPE_E = class_2248.method_9541( 0, 0, 0, 2, 32, 16);

    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return switch (state.method_11654(field_11177)) {
            case field_11043 -> SHAPE_N;
            case field_11035 -> SHAPE_S;
            case field_11039 -> SHAPE_W;
            case field_11034 -> SHAPE_E;
            default -> SHAPE_N;
        };
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 context) {
        return this.method_9564().method_11657(field_11177, context.method_8042().method_10153());
    }

    @Override
    protected boolean method_9516(class_2680 state, class_10 pathComputationType) {
        return false;
    }

@Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        class_2350 direction = state.method_11654(field_11177);
        class_2338 blockPos = pos.method_10093(direction.method_10153());
        class_2680 blockState = level.method_8320(blockPos);
        return blockState.method_26206(level, blockPos, direction);
    }
    
    @Override
    protected class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        return direction.method_10153() == state.method_11654(field_11177) && !this.method_9558(state, level, pos)
            ? class_2246.field_10124.method_9564()
            : state;
    }

    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(field_11177, rotation.method_10503(state.method_11654(field_11177)));
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(field_11177)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177);
    }
}