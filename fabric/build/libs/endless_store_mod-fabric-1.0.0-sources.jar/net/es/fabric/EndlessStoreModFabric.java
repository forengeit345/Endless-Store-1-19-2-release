package net.es.fabric;

import net.es.EndlessStoreMod;
import net.es.block.EndlessStoreBlocks;
import net.es.block.custom.BedsideTable;
import net.es.block.custom.CardboardBoxHugeTape;
import net.es.block.custom.CustomFurnaceBlock;
import net.es.block.custom.OldSafe;
import net.es.block.entity.BedsideTableEntity;
import net.es.block.entity.CardboardBoxHugeTapeEntity;
import net.es.block.entity.CustomFurnaceBlockEntity;
import net.es.block.entity.OldSafeEntity;
import net.es.entity.ConfigurableHeightSpawnRestriction;
import net.es.entity.EndlessStoreEntities;
import net.es.entity.custom.*;
import net.es.fluid.CustomFluidBlock;
import net.es.fluid.CustomWaterFluidBlock;
import net.es.fluid.EndlessStoreFluids;
import net.es.item.EndlessStoreItemGroup;
import net.es.item.EndlessStoreItems;
import net.es.registry.EndlessStoreFeatures;
import net.es.registry.EndlessStoreFuel;
import net.es.screen.DimensionEnterHandler;
import net.es.screen.PlayerDeathHandler;
import net.es.world.dimension.EndlessStoreDimension;
import net.es.world.features.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_3222;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.LinkedHashMap;
import java.util.Map;

public class EndlessStoreModFabric implements ModInitializer {
    private static final Map<String, class_1792> ITEMS = new LinkedHashMap<>();

    @Override
    public void onInitialize() {

        ServerTickEvents.START_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                DimensionEnterHandler.onPlayerTick(player);
            }
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            PlayerDeathHandler.handleRespawn(oldPlayer, newPlayer);
        });

//        Фичи для генерации мира
        class_3031<class_3111> hillsFeature = new HillsOfBoxes();
        class_2378.method_10230(
                class_7923.field_41144,
                class_2960.method_60655(EndlessStoreMod.MOD_ID, "hills_of_boxes"),
                hillsFeature
        );
        EndlessStoreFeatures.HILLS_OF_BOXES = () -> hillsFeature;

        class_3031<class_3111> sinWaveHillFeature = new SinWaveHillFeature();
        class_2378.method_10230(
                class_7923.field_41144,
                class_2960.method_60655(EndlessStoreMod.MOD_ID, "sin_wave_hill"),
                sinWaveHillFeature
        );
        EndlessStoreFeatures.SIN_WAVE_HILL_FEATURE = () -> sinWaveHillFeature;

        class_3031<class_3111> toxicLakeFeature = new ToxicLake();
        class_2378.method_10230(
                class_7923.field_41144,
                class_2960.method_60655(EndlessStoreMod.MOD_ID, "toxic_lake"),
                toxicLakeFeature
        );
        EndlessStoreFeatures.TOXIC_LAKE = () -> toxicLakeFeature;

        class_3031<class_3111> trashLandfillFeature = new TrashLandfill();
        class_2378.method_10230(
                class_7923.field_41144,
                class_2960.method_60655(EndlessStoreMod.MOD_ID, "trash_landfill"),
                trashLandfillFeature
        );
        EndlessStoreFeatures.TRASH_LANDFILL = () -> trashLandfillFeature;

        class_3031<class_3111> chainMailTreesFeature = new ChainMailTrees();
        class_2378.method_10230(
                class_7923.field_41144,
                class_2960.method_60655(EndlessStoreMod.MOD_ID, "chain_mail_trees"),
                chainMailTreesFeature
        );
        EndlessStoreFeatures.CHAIN_MAIL_TREES = () -> chainMailTreesFeature;

        class_3031<class_3111> abandonedHillsFeature = new AbandonedHills();
        class_2378.method_10230(
                class_7923.field_41144,
                class_2960.method_60655(EndlessStoreMod.MOD_ID, "abandoned_hills"),
                abandonedHillsFeature
        );
        EndlessStoreFeatures.ABANDONED_HILLS = () -> abandonedHillsFeature;

//        Работничек

        class_1299<EmployeeEntity> employeeType = class_1299.class_1300.method_5903(
                        EmployeeEntity::new,
                        class_1311.field_6302)
                .method_17687(0.8f, 1.85f)
                .method_5905("employee");

        class_2378.method_10230(
                class_7923.field_41177,
                class_2960.method_60655(EndlessStoreMod.MOD_ID, "employee"),
                employeeType
        );
        EndlessStoreEntities.EMPLOYEE = () -> employeeType;

//        Джэк

        class_1299<JackEntity> jackType = class_1299.class_1300.method_5903(
                        JackEntity::new,
                        class_1311.field_6302)
                .method_17687(0.4f, 1.1f)
                .method_5905("jack");

        class_2378.method_10230(
                class_7923.field_41177,
                class_2960.method_60655(EndlessStoreMod.MOD_ID, "jack"),
                jackType
        );
        EndlessStoreEntities.JACK = () -> jackType;

//        Охранник

        class_1299<SecurityEntity> securityType = class_1299.class_1300.method_5903(
                        SecurityEntity::new,
                        class_1311.field_6302)
                .method_17687(0.8f, 1.85f)
                .method_5905("security");

        class_2378.method_10230(
                class_7923.field_41177,
                class_2960.method_60655(EndlessStoreMod.MOD_ID, "security"),
                securityType
        );
        EndlessStoreEntities.SECURITY = () -> securityType;

        //        Смотритель

        class_1299<WatcherEntity> watcherType = class_1299.class_1300.method_5903(
                        WatcherEntity::new,
                        class_1311.field_6302)
                .method_17687(0.85f, 3.25f)
                .method_5905("watcher");

        class_2378.method_10230(
                class_7923.field_41177,
                class_2960.method_60655(EndlessStoreMod.MOD_ID, "watcher"),
                watcherType
        );
        EndlessStoreEntities.WATCHER = () -> watcherType;

        //        Водомерка

        class_1299<WaterStriderEntity> waterStriderType = class_1299.class_1300.method_5903(
                        WaterStriderEntity::new,
                        class_1311.field_6302)
                .method_17687(0.8f, 0.7f)
                .method_5905("water_strider");

        class_2378.method_10230(
                class_7923.field_41177,
                class_2960.method_60655(EndlessStoreMod.MOD_ID, "water_strider"),
                waterStriderType
        );
        EndlessStoreEntities.WATER_STRIDER = () -> waterStriderType;

        // 1. Сначала регистрируем БЛОКИ (они попадут в карту первыми)
        EndlessStoreBlocks.registerBlocks(
                (name, blockFactory) -> {
                    class_2248 block = blockFactory.get();
                    class_2378.method_10230(
                            class_7923.field_41175,
                            class_2960.method_60655(EndlessStoreMod.MOD_ID, name),
                            block
                    );
                    return () -> block;
                },
                (name, itemFactory) -> {
                    class_1792 item = itemFactory.get();
                    class_2378.method_10230(
                            class_7923.field_41178,
                            class_2960.method_60655(EndlessStoreMod.MOD_ID, name),
                            item
                    );
                    ITEMS.put(name, item); // BlockItem вставляется в карту
                }
        );

        // 2. Затем регистрируем ОБЫЧНЫЕ ПРЕДМЕТЫ (добавляются после блоков)
        EndlessStoreItems.registerItems((name, factory) -> {
            class_1792 item = factory.get();
            class_2378.method_10230(
                    class_7923.field_41178,
                    class_2960.method_60655(EndlessStoreMod.MOD_ID, name),
                    item
            );
            ITEMS.put(name, item);

            // Если это пластиковое ведро, сохраняем поставщик
            if (name.equals(EndlessStoreItems.PLASTIC_BUCKET)) {
                EndlessStoreItems.PLASTIC_BUCKET_ITEM = () -> item;
            }
        });

//        TODO: БлокЭнтити
        class_2591<BedsideTableEntity> bedsideType = class_2591.class_2592.method_20528(
                BedsideTableEntity::new,
                class_7923.field_41175.method_10223(
                        class_2960.method_60655(EndlessStoreMod.MOD_ID, EndlessStoreBlocks.BEDSIDE_TABLE)
                )
        ).method_11034(null);

        class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(EndlessStoreMod.MOD_ID, "bedside_table"), bedsideType);
        BedsideTable.TYPE = () -> bedsideType;

//        2

        class_2591<CardboardBoxHugeTapeEntity> cardboardBoxHugeTapeEntityBlockEntityType = class_2591.class_2592.method_20528(
                CardboardBoxHugeTapeEntity::new,
                class_7923.field_41175.method_10223(
                        class_2960.method_60655(EndlessStoreMod.MOD_ID, EndlessStoreBlocks.CARDBOARD_BOX_HUGE_TAPE)
                )
        ).method_11034(null);

        class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(EndlessStoreMod.MOD_ID, "cardboard_box_huge_tape"), cardboardBoxHugeTapeEntityBlockEntityType);
        CardboardBoxHugeTape.TYPE = () -> cardboardBoxHugeTapeEntityBlockEntityType;

//        3

        class_2591<CustomFurnaceBlockEntity> furnaceType = class_2591.class_2592.method_20528(
                CustomFurnaceBlockEntity::new,
                class_7923.field_41175.method_10223(
                        class_2960.method_60655(EndlessStoreMod.MOD_ID, EndlessStoreBlocks.CONCRETE_FURNACE)
                )
        ).method_11034(null);

        class_2378.method_10230(
                class_7923.field_41181,
                class_2960.method_60655(EndlessStoreMod.MOD_ID, "concrete_furnace"),
                furnaceType
        );

        CustomFurnaceBlock.TYPE = () -> furnaceType;

//        4

        class_1299<PlateEntity> plateType = class_1299.class_1300.method_5903(
                        (class_1299.class_4049<PlateEntity>) PlateEntity::new,
                        class_1311.field_17715)
                .method_17687(0.5F, 0.5F)
                .method_27299(10)
                .method_27300(1)
                .method_5905("plate");

        class_2378.method_10230(
                class_7923.field_41177,
                class_2960.method_60655(EndlessStoreMod.MOD_ID, "plate"),
                plateType
        );
        EndlessStoreEntities.PLATE = () -> plateType;

//        5

        class_2591<OldSafeEntity> oldSafeType = class_2591.class_2592.method_20528(
                OldSafeEntity::new,
                class_7923.field_41175.method_10223(
                        class_2960.method_60655(EndlessStoreMod.MOD_ID, EndlessStoreBlocks.OLD_SAFE)
                )
        ).method_11034(null);

        class_2378.method_10230(
                class_7923.field_41181,
                class_2960.method_60655(EndlessStoreMod.MOD_ID, "old_safe"),
                oldSafeType
        );

        OldSafe.TYPE = () -> oldSafeType;

//        TODO: ИНИТ
        EndlessStoreFluids.init((name, stillFactory, flowingFactory, blockFactory, bucketFactory) -> {
            //            Регистарция мобов
            FabricDefaultAttributeRegistry.register(EndlessStoreEntities.EMPLOYEE.get(), EmployeeEntity.createAttributes());
            FabricDefaultAttributeRegistry.register(EndlessStoreEntities.JACK.get(), JackEntity.createAttributes());
            FabricDefaultAttributeRegistry.register(EndlessStoreEntities.SECURITY.get(), SecurityEntity.createAttributes());
            FabricDefaultAttributeRegistry.register(EndlessStoreEntities.WATCHER.get(), WatcherEntity.createAttributes());
            FabricDefaultAttributeRegistry.register(EndlessStoreEntities.WATER_STRIDER.get(), WaterStriderEntity.createAttributes());

            // Регистрируем стоячую жидкость
            class_3611 still = class_2378.method_10230(
                    class_7923.field_41173,
                    class_2960.method_60655(EndlessStoreMod.MOD_ID, name),
                    stillFactory.get()
            );

//            Регистрация высоты мобов
            ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
                if (entity instanceof class_1308 mob) {
                    // Для загруженных мобов проверяем их текущую высоту
                    if (!ConfigurableHeightSpawnRestriction.checkSpawn(mob, mob.method_23318())) {
                        mob.method_31472(); // удаляем, если высота не подходит
                    }
                }
            });

            // Регистрируем текучую жидкость
            class_3609 flowing = class_2378.method_10230(
                    class_7923.field_41173,
                    class_2960.method_60655(EndlessStoreMod.MOD_ID, "flowing_" + name),
                    flowingFactory.get()
            );

            // Сразу назначаем поставщики, чтобы blockFactory.get() мог бы их использовать (но мы его не вызываем)
            if (name.equals("acid")) {
                EndlessStoreFluids.ACID = () -> still;
                EndlessStoreFluids.FLOWING_ACID = () -> flowing;
            } else if (name.equals("waste_water")) {
                EndlessStoreFluids.WASTE_WATER = () -> still;
                EndlessStoreFluids.FLOWING_WASTE_WATER = () -> flowing;
            }

            // Создаём блок жидкости напрямую, используя уже полученную текучую жидкость,
            // чтобы избежать обращения к ещё не инициализированному FLOWING_ACID.
            class_2248 block = new CustomFluidBlock(flowing, class_2248.Properties.method_9630(class_2246.field_10382).method_51371());
            class_2378.method_10230(
                    class_7923.field_41175,
                    class_2960.method_60655(EndlessStoreMod.MOD_ID, name + "_block"),
                    block
            );

            class_2248 blockWater = new CustomWaterFluidBlock(flowing, class_2248.Properties.method_9630(class_2246.field_10382).method_51371());
            class_2378.method_10230(
                    class_7923.field_41175,
                    class_2960.method_60655(EndlessStoreMod.MOD_ID, name + "_block"),
                    blockWater
            );

            if (name.equals("acid")) {
                EndlessStoreFluids.ACID_BLOCK = () -> block;
            } else if (name.equals("waste_water")) {
                EndlessStoreFluids.WASTE_WATER_BLOCK = () -> blockWater;
            }

            // Ведро (если передано)
            if (bucketFactory != null) {
                class_1792 bucket = bucketFactory.get();
                class_2378.method_10230(
                        class_7923.field_41178,
                        class_2960.method_60655(EndlessStoreMod.MOD_ID, "plastic_" + name + "_bucket"),
                        bucket
                );

                if (name.equals("acid")) {
                    EndlessStoreFluids.PLASTIC_ACID_BUCKET = () -> bucket;
                } else if (name.equals("waste_water")) {
                    EndlessStoreFluids.PLASTIC_WASTE_WATER_BUCKET = () -> bucket;
                }

                ITEMS.put("plastic_" + name + "_bucket", bucket);
            }
        });

//        Регистрация измерения
        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            class_2378<class_5363> registry = server.method_30611().method_30530(class_7924.field_41224);
            if (!registry.method_35842(EndlessStoreDimension.ESDIM_KEY)) {
            }
        });

        // Творческая вкладка
        class_5321<class_1761> tabKey = class_5321.method_29179(
                class_7924.field_44688,
                class_2960.method_60655(EndlessStoreMod.MOD_ID, "endless_store_tab")
        );

        class_2378.method_39197(class_7923.field_44687, tabKey, EndlessStoreItemGroup.ENDLESS_STORE_TAB.get());

        ItemGroupEvents.modifyEntriesEvent(tabKey).register(content -> {
            ITEMS.values().forEach(content::method_45421);
        });

//        6 Топляк
        EndlessStoreFuel.FUEL_VALUES.forEach((name, burnTime) -> {
            class_1792 item = ITEMS.get(name);
            if (item != null) {
                FuelRegistry.INSTANCE.add(item, burnTime);
            }
        });
    }
}