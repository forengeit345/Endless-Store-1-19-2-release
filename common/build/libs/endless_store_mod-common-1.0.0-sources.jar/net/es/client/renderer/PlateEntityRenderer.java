package net.es.client.renderer;

import net.es.entity.PlateEntity;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_897;
import net.minecraft.class_918;

public class PlateEntityRenderer extends class_897<PlateEntity> {
    private final class_918 itemRenderer;

    public PlateEntityRenderer(class_5617.class_5618 context) {
        super(context);
        this.itemRenderer = context.method_32168();
    }

    @Override
    public void render(PlateEntity entity, float entityYaw, float partialTicks, class_4587 matrices,
                       class_4597 buffer, int packedLight) {
        class_1799 stack = entity.getItem();
        if (stack.method_7960()) return;

        matrices.method_22903();

        matrices.method_22907(class_7833.field_40714.rotationDegrees(90.0F));

        float rotation = entity.getRotation() * 45.0F;
        matrices.method_22907(class_7833.field_40718.rotationDegrees(rotation));

        // Масштаб: для блоков чуть меньше, для остальных предметов — как у рамки
        float scale = stack.method_7909() instanceof class_1747 ? 0.4F : 0.225F;
        matrices.method_22905(scale, scale, scale);

        // Яркий фиксированный свет (полный небесный и блоковый свет)
        int light = class_765.method_23687(15, 15);
        itemRenderer.method_23178(
                stack,
                class_811.field_4319,
                light,
                class_4608.field_21444,
                matrices,
                buffer,
                entity.method_37908(),
                entity.method_5628()
        );

        matrices.method_22909();
    }

    @Override
    public class_2960 getTextureLocation(PlateEntity entity) {
        return null; // не используется, т.к. рисуем только предмет
    }
}