package net.es.block.custom;

import net.minecraft.class_2510;
import net.minecraft.class_2680;

public class CustomStairsBlock extends class_2510 {
    public CustomStairsBlock(class_2680 baseBlockState, class_2251 properties) {
        super(baseBlockState, properties);
    }
}
